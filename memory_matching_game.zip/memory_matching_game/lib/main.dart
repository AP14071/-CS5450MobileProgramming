import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MemoryMatchApp());
}

class MemoryMatchApp extends StatelessWidget {
  const MemoryMatchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Memory Match Game',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.deepPurple),
      home: const StartScreen(),
    );
  }
}

class MemoryCard {
  final String value;
  bool isFlipped;
  bool isMatched;

  MemoryCard({
    required this.value,
    this.isFlipped = false,
    this.isMatched = false,
  });
}

class StartScreen extends StatefulWidget {
  const StartScreen({super.key});

  @override
  State<StartScreen> createState() => _StartScreenState();
}

class _StartScreenState extends State<StartScreen> {
  String difficulty = 'Easy';
  String theme = 'Fruits';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF3F0E9E),
              Color(0xFF7B2FF7),
              Color(0xFFF3E5F5),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 130,
                height: 130,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withAlpha(45),
                      blurRadius: 12,
                      offset: const Offset(2, 6),
                    ),
                  ],
                ),
                child: const Center(
                  child: Text('🧠⭐', style: TextStyle(fontSize: 48)),
                ),
              ),
              const SizedBox(height: 22),
              const Text(
                'MEMORY',
                style: TextStyle(
                  fontSize: 48,
                  fontWeight: FontWeight.w900,
                  color: Color(0xFFFFCA28),
                  letterSpacing: 2,
                  shadows: [
                    Shadow(
                      color: Colors.black38,
                      blurRadius: 8,
                      offset: Offset(2, 4),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.pinkAccent,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: const Text(
                  'MATCH GAME',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'Flip cards, find pairs,\nand beat your best score!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 19,
                  height: 1.3,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 32),
              _selectBox(
                icon: Icons.bar_chart_rounded,
                label: 'Difficulty',
                value: difficulty,
                items: ['Easy', 'Medium', 'Hard'],
                onChanged: (value) => setState(() => difficulty = value!),
              ),
              const SizedBox(height: 16),
              _selectBox(
                icon: Icons.palette_rounded,
                label: 'Theme',
                value: theme,
                items: ['Fruits', 'Animals', 'Emojis'],
                onChanged: (value) => setState(() => theme = value!),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                height: 62,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    foregroundColor: Colors.white,
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(35),
                      side: const BorderSide(
                        color: Color(0xFFFFCA28),
                        width: 2,
                      ),
                    ),
                  ),
                  icon: const Icon(Icons.play_arrow, size: 30),
                  label: const Text(
                    'Start Game',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => GameScreen(
                          difficulty: difficulty,
                          theme: theme,
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 28),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withAlpha(235),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _StartBottomItem(
                      icon: Icons.emoji_events,
                      title: 'Best Moves',
                    ),
                    _StartBottomItem(
                      icon: Icons.timer,
                      title: 'Best Time',
                    ),
                    _StartBottomItem(
                      icon: Icons.star,
                      title: 'Have Fun',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _selectBox({
    required IconData icon,
    required String label,
    required String value,
    required List<String> items,
    required Function(String?) onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(30),
            blurRadius: 8,
            offset: const Offset(2, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.deepPurple, size: 34),
          const SizedBox(width: 14),
          Expanded(
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: value,
                isExpanded: true,
                items: items.map((item) {
                  return DropdownMenuItem<String>(
                    value: item,
                    child: Text(
                      '$label: $item',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  );
                }).toList(),
                onChanged: onChanged,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StartBottomItem extends StatelessWidget {
  final IconData icon;
  final String title;

  const _StartBottomItem({
    required this.icon,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: Colors.deepPurple),
        const SizedBox(height: 5),
        Text(title),
      ],
    );
  }
}

class GameScreen extends StatefulWidget {
  final String difficulty;
  final String theme;

  const GameScreen({
    super.key,
    required this.difficulty,
    required this.theme,
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  List<MemoryCard> cards = [];
  int? firstIndex;
  int? secondIndex;
  int moves = 0;
  int matchedPairs = 0;
  int seconds = 0;
  int bestMoves = 0;
  int bestTime = 0;
  bool isChecking = false;
  Timer? timer;

  final Map<String, List<String>> themes = {
    'Fruits': [
      '🍎', '🍌', '🍇', '🍓', '🍍', '🥝',
      '🍉', '🍒', '🥭', '🍑', '🍋', '🍐'
    ],
    'Animals': [
      '🐶', '🐱', '🦁', '🐯', '🐼', '🐸',
      '🐵', '🐰', '🦊', '🐻', '🐨', '🐷'
    ],
    'Emojis': [
      '😀', '😍', '😎', '🥳', '😇', '🤩',
      '😜', '😭', '😡', '😱', '😴', '🤠'
    ],
  };

  @override
  void initState() {
    super.initState();
    loadBestScore();
    startGame();
  }

  int get pairCount {
    if (widget.difficulty == 'Easy') return 8;
    if (widget.difficulty == 'Medium') return 10;
    return 12;
  }

  int get crossAxisCount => 4;

  String get scoreKey => '${widget.difficulty}_${widget.theme}';

  Future<void> loadBestScore() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      bestMoves = prefs.getInt('${scoreKey}_moves') ?? 0;
      bestTime = prefs.getInt('${scoreKey}_time') ?? 0;
    });
  }

  Future<void> saveBestScore() async {
    final prefs = await SharedPreferences.getInstance();

    if (bestMoves == 0 || moves < bestMoves) {
      await prefs.setInt('${scoreKey}_moves', moves);
      bestMoves = moves;
    }

    if (bestTime == 0 || seconds < bestTime) {
      await prefs.setInt('${scoreKey}_time', seconds);
      bestTime = seconds;
    }
  }

  void startGame() {
    final selectedItems = themes[widget.theme]!.take(pairCount).toList();
    final duplicated = [...selectedItems, ...selectedItems];
    duplicated.shuffle(Random());

    setState(() {
      cards = duplicated.map((e) => MemoryCard(value: e)).toList();
      firstIndex = null;
      secondIndex = null;
      moves = 0;
      matchedPairs = 0;
      seconds = 0;
      isChecking = false;
    });

    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => seconds++);
    });
  }

  void flipCard(int index) {
    if (isChecking || cards[index].isFlipped || cards[index].isMatched) return;

    setState(() {
      cards[index].isFlipped = true;

      if (firstIndex == null) {
        firstIndex = index;
      } else {
        secondIndex = index;
        moves++;
        isChecking = true;
      }
    });

    if (secondIndex != null) {
      checkMatch();
    }
  }

  void checkMatch() {
    final firstCard = cards[firstIndex!];
    final secondCard = cards[secondIndex!];

    if (firstCard.value == secondCard.value) {
      setState(() {
        firstCard.isMatched = true;
        secondCard.isMatched = true;
        matchedPairs++;
        firstIndex = null;
        secondIndex = null;
        isChecking = false;
      });

      if (matchedPairs == pairCount) {
        timer?.cancel();
        saveBestScore();
        showWinDialog();
      }
    } else {
      Future.delayed(const Duration(milliseconds: 750), () {
        setState(() {
          firstCard.isFlipped = false;
          secondCard.isFlipped = false;
          firstIndex = null;
          secondIndex = null;
          isChecking = false;
        });
      });
    }
  }

  int starRating() {
    if (moves <= pairCount + 4) return 3;
    if (moves <= pairCount + 10) return 2;
    return 1;
  }

  String formatTime(int totalSeconds) {
    final minutes = totalSeconds ~/ 60;
    final secs = totalSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  void showWinDialog() {
    final stars = '⭐' * starRating();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Congratulations!'),
        content: Text(
          'You completed the game!\n\n'
              'Rating: $stars\n'
              'Moves: $moves\n'
              'Time: ${formatTime(seconds)}\n\n'
              'Best Moves: $bestMoves\n'
              'Best Time: ${formatTime(bestTime)}',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              startGame();
            },
            child: const Text('Play Again'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Home'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final progress = matchedPairs / pairCount;

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.difficulty} - ${widget.theme}'),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        elevation: 6,
      ),
      body: Container(
        padding: const EdgeInsets.all(14),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF4A00E0),
              Color(0xFF8E2DE2),
              Color(0xFFF3E5F5),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white.withAlpha(235),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withAlpha(35),
                    blurRadius: 10,
                    offset: const Offset(2, 5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(child: _InfoBox(title: 'Moves', value: '$moves')),
                      const SizedBox(width: 8),
                      Expanded(child: _InfoBox(title: 'Time', value: formatTime(seconds))),
                      const SizedBox(width: 8),
                      Expanded(child: _InfoBox(title: 'Best', value: bestMoves == 0 ? '-' : '$bestMoves')),
                    ],
                  ),
                  const SizedBox(height: 14),
                  LinearProgressIndicator(
                    value: progress,
                    minHeight: 12,
                    borderRadius: BorderRadius.circular(20),
                    backgroundColor: Colors.deepPurple.withAlpha(35),
                    color: Colors.pinkAccent,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Progress: $matchedPairs / $pairCount pairs',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.deepPurple,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: GridView.builder(
                itemCount: cards.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: crossAxisCount,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemBuilder: (context, index) {
                  return MemoryCardTile(
                    card: cards[index],
                    onTap: () => flipCard(index),
                  );
                },
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: startGame,
                icon: const Icon(Icons.restart_alt),
                label: const Text(
                  'Restart Game',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                    side: const BorderSide(
                      color: Color(0xFFFFCA28),
                      width: 2,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoBox extends StatelessWidget {
  final String title;
  final String value;

  const _InfoBox({
    required this.title,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(25),
            blurRadius: 6,
            offset: const Offset(2, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          Text(value, style: const TextStyle(color: Colors.deepPurple)),
        ],
      ),
    );
  }
}

class MemoryCardTile extends StatelessWidget {
  final MemoryCard card;
  final VoidCallback onTap;

  const MemoryCardTile({
    super.key,
    required this.card,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final showFront = card.isFlipped || card.isMatched;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedScale(
        scale: card.isMatched ? 0.93 : 1.0,
        duration: const Duration(milliseconds: 220),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          decoration: BoxDecoration(
            gradient: showFront
                ? const LinearGradient(
              colors: [Colors.white, Color(0xFFFFF8E1)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            )
                : const LinearGradient(
              colors: [Color(0xFF7B2FF7), Color(0xFF4A00E0)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: card.isMatched
                  ? Colors.greenAccent
                  : Colors.white.withAlpha(70),
              width: card.isMatched ? 4 : 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: card.isMatched
                    ? Colors.greenAccent.withAlpha(120)
                    : Colors.black.withAlpha(45),
                blurRadius: card.isMatched ? 14 : 8,
                offset: const Offset(2, 5),
              ),
            ],
          ),
          child: Center(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 280),
              transitionBuilder: (child, animation) {
                return ScaleTransition(scale: animation, child: child);
              },
              child: showFront
                  ? Text(
                card.value,
                key: ValueKey(card.value),
                style: const TextStyle(fontSize: 36),
              )
                  : const Text(
                '?',
                key: ValueKey('back'),
                style: TextStyle(
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  shadows: [
                    Shadow(
                      color: Colors.black38,
                      blurRadius: 6,
                      offset: Offset(2, 3),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}