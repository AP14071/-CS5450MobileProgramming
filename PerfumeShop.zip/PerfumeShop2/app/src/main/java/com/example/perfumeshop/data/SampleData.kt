package com.example.perfumeshop.data

import com.example.perfumeshop.R
import com.example.perfumeshop.model.Product

val perfumeList = listOf(
    Product(
        "Dior Sauvage",
        120.0,
        R.drawable.perfume1,
        "Citrus",
        5.0,
        "A bold and fresh citrus fragrance with a luxury masculine touch."
    ),
    Product(
        "Chanel No.5",
        150.0,
        R.drawable.perfume2,
        "Floral",
        4.6,
        "A timeless floral perfume with elegant and classic notes."
    ),
    Product(
        "Versace Eros",
        110.0,
        R.drawable.perfume3,
        "Sweet",
        4.7,
        "A sweet and powerful scent with fresh and warm fragrance notes."
    ),
    Product(
        "Gucci Bloom",
        130.0,
        R.drawable.perfume4,
        "Fresh",
        4.5,
        "A fresh floral perfume inspired by natural garden scents."
    ),
    Product(
        "YSL Libre",
        145.0,
        R.drawable.perfume5,
        "Woody",
        4.8,
        "A luxury woody fragrance with bold, warm, and elegant notes."
    )
)