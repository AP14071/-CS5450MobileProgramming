package com.example.perfumeshop.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.perfumeshop.model.Product

@Composable
fun ProductDetailScreen(
    product: Product,
    cart: SnapshotStateList<Product>,
    goBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFF7FB))
            .padding(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = goBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }

            Text("Product Details", fontSize = 20.sp, fontWeight = FontWeight.Bold)

            IconButton(onClick = {}) {
                Icon(
                    Icons.Default.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = Color(0xFFD81B60)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .background(Color(0xFFF3EAF7), RoundedCornerShape(30.dp)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = product.image),
                contentDescription = product.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(230.dp)
                    .clip(RoundedCornerShape(22.dp))
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    product.name,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF24112E)
                )

                Text(
                    product.fragranceType,
                    fontSize = 16.sp,
                    color = Color(0xFF8E24AA)
                )
            }

            Text(
                "$${product.price}",
                fontSize = 24.sp,
                color = Color(0xFF8E24AA),
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            "⭐ ${product.rating}  •  Premium Fragrance",
            fontSize = 15.sp,
            color = Color(0xFFD4AF37)
        )

        Spacer(modifier = Modifier.height(22.dp))

        Text(
            "About this Perfume",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF24112E)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            product.description,
            fontSize = 15.sp,
            color = Color.Gray,
            lineHeight = 22.sp
        )

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = {
                cart.add(product)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF8E24AA)
            )
        ) {
            Text("Add to Bag", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
    }
}