package com.example.perfumeshop.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.perfumeshop.R

@Composable
fun WelcomeScreen(
    onStartClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF8E24AA),
                        Color(0xFFD81B60)
                    )
                )
            )
            .padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(155.dp)
                    .background(
                        Color.White.copy(alpha = 0.15f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "Perfume Shop Logo",
                    modifier = Modifier.size(115.dp)
                )
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "Welcome to",
                fontSize = 24.sp,
                color = Color.White
            )

            Text(
                text = "La Parfumerie",
                fontSize = 40.sp,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Discover luxury fragrances for every mood.",
                fontSize = 16.sp,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(36.dp))

            Button(
                onClick = onStartClick,
                shape = RoundedCornerShape(50.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color(0xFF8E24AA)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Start Shopping")
            }
        }
    }
}