package com.example.perfumeshop.model

data class Product(
    val name: String,
    val price: Double,
    val image: Int,
    val fragranceType: String,
    val rating: Double,
    val description: String
)