package com.example.perfumeshop.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.perfumeshop.model.Product

@Composable
fun ProductCard(
    product: Product,
    onAddToCart: () -> Unit,
    onProductClick: () -> Unit
) {
    var added by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .width(195.dp)
            .padding(8.dp)
            .clickable { onProductClick() }
            .animateContentSize(),
        shape = RoundedCornerShape(28.dp),
        elevation = CardDefaults.cardElevation(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row {
                    Text(
                        text = product.fragranceType,
                        fontSize = 11.sp,
                        color = Color(0xFF8E24AA),
                        modifier = Modifier
                            .background(Color(0xFFF3E5F5), RoundedCornerShape(50.dp))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    )

                    if (product.name == "Dior Sauvage") {
                        Spacer(modifier = Modifier.width(5.dp))

                        Text(
                            text = "HOT",
                            fontSize = 10.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .background(Color(0xFFC98A00), RoundedCornerShape(50.dp))
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.FavoriteBorder,
                    contentDescription = "Wishlist",
                    tint = Color(0xFFD81B60)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .size(135.dp)
                    .background(Color(0xFFF3EAF7), RoundedCornerShape(26.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = product.image),
                    contentDescription = product.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .size(125.dp)
                        .clip(RoundedCornerShape(18.dp))
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = product.name,
                fontSize = 15.sp,
                maxLines = 1,
                fontWeight = FontWeight.SemiBold
            )

            Text(
                text = "⭐ ${product.rating}",
                fontSize = 13.sp,
                color = Color(0xFFC98A00)
            )

            Text(
                text = "$${product.price}",
                fontSize = 16.sp,
                color = Color(0xFF8E24AA),
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    onAddToCart()
                    added = true
                },
                shape = RoundedCornerShape(50.dp),
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (added) Color(0xFF2E7D32) else Color(0xFF8E24AA)
                )
            ) {
                Text(
                    text = if (added) "Added ✓" else "Add to Bag",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}