package com.example.perfumeshop.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.perfumeshop.model.Product

@Composable
fun CartScreen(
    cart: SnapshotStateList<Product>,
    goBack: () -> Unit
) {
    var showMessage by remember { mutableStateOf(false) }

    val groupedCart = cart.groupBy { it.name }

    val subtotal = cart.sumOf { it.price }
    val tax = subtotal * 0.13
    val total = subtotal + tax

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF6F1F8))
            .padding(18.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = goBack) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFF24112E)
                )
            }

            Text(
                text = "My Shopping Bag",
                fontSize = 25.sp,
                color = Color(0xFF24112E)
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        if (cart.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 80.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.ShoppingBag,
                    contentDescription = "Empty Bag",
                    tint = Color(0xFF8E24AA),
                    modifier = Modifier.size(70.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Your bag is empty",
                    fontSize = 22.sp,
                    color = Color(0xFF24112E)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Add your favorite fragrances to continue.",
                    fontSize = 14.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = goBack,
                    shape = RoundedCornerShape(50.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF8E24AA)
                    )
                ) {
                    Text("Continue Shopping")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f)
            ) {
                items(groupedCart.keys.toList()) { productName ->

                    val productItems = groupedCart[productName] ?: emptyList()
                    val product = productItems.first()
                    val quantity = productItems.size

                    ElevatedCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 7.dp),
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = Color.White
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = product.image),
                                contentDescription = product.name,
                                modifier = Modifier
                                    .size(85.dp)
                                    .clip(RoundedCornerShape(18.dp))
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(product.name, fontSize = 17.sp, maxLines = 1)
                                Text(
                                    product.fragranceType,
                                    fontSize = 13.sp,
                                    color = Color(0xFF8E24AA)
                                )
                                Text(
                                    "$${String.format("%.2f", product.price)} x $quantity",
                                    color = Color.Gray
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = {
                                        cart.remove(product)
                                    },
                                    modifier = Modifier.size(34.dp),
                                    contentPadding = PaddingValues(0.dp),
                                    shape = RoundedCornerShape(50.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFF3E5F5),
                                        contentColor = Color(0xFF8E24AA)
                                    )
                                ) {
                                    Text("-", fontSize = 18.sp)
                                }

                                Text(
                                    text = quantity.toString(),
                                    fontSize = 17.sp,
                                    modifier = Modifier.padding(horizontal = 12.dp)
                                )

                                Button(
                                    onClick = {
                                        cart.add(product)
                                    },
                                    modifier = Modifier.size(34.dp),
                                    contentPadding = PaddingValues(0.dp),
                                    shape = RoundedCornerShape(50.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF8E24AA),
                                        contentColor = Color.White
                                    )
                                ) {
                                    Text("+", fontSize = 18.sp)
                                }
                            }
                        }
                    }
                }
            }

            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = Color.White
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Subtotal", fontSize = 16.sp, color = Color.Gray)
                        Text("$${String.format("%.2f", subtotal)}", fontSize = 16.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Tax (13%)", fontSize = 16.sp, color = Color.Gray)
                        Text("$${String.format("%.2f", tax)}", fontSize = 16.sp)
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Total Payment", fontSize = 20.sp)
                        Text(
                            "$${String.format("%.2f", total)}",
                            fontSize = 22.sp,
                            color = Color(0xFF8E24AA)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            showMessage = true
                            cart.clear()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF8E24AA)
                        )
                    ) {
                        Text("Checkout")
                    }

                    if (showMessage) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Order placed successfully!",
                            color = Color(0xFF2E7D32),
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}