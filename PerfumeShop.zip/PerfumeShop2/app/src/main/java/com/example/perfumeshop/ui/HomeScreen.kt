package com.example.perfumeshop.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.perfumeshop.data.perfumeList
import com.example.perfumeshop.model.Product

@Composable
fun HomeScreen(
    cart: SnapshotStateList<Product>,
    goToCart: () -> Unit,
    onProductClick: (Product) -> Unit
) {
    var selectedType by remember { mutableStateOf("All") }

    val fragranceTypes = listOf(
        "All",
        "Citrus",
        "Floral",
        "Sweet",
        "Fresh",
        "Woody"
    )

    val filteredProducts =
        if (selectedType == "All") perfumeList
        else perfumeList.filter { it.fragranceType == selectedType }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF6F1F8))
            .verticalScroll(rememberScrollState())
            .padding(18.dp)
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Column {
                Text(
                    "Hello Ayush",
                    fontSize = 17.sp,
                    color = Color.Gray
                )

                Text(
                    "Find Your Signature Scent",
                    fontSize = 24.sp,
                    color = Color(0xFF24112E)
                )
            }

            BadgedBox(
                badge = {
                    if (cart.isNotEmpty()) {
                        Badge {
                            Text(cart.size.toString())
                        }
                    }
                }
            ) {
                IconButton(onClick = goToCart) {
                    Icon(
                        imageVector = Icons.Default.ShoppingBag,
                        contentDescription = "Cart",
                        tint = Color(0xFF8E24AA)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .shadow(
                    elevation = 12.dp,
                    shape = RoundedCornerShape(30.dp)
                )
                .background(
                    brush = Brush.horizontalGradient(
                        listOf(
                            Color(0xFF6A1B9A),
                            Color(0xFFD81B60)
                        )
                    ),
                    shape = RoundedCornerShape(30.dp)
                )
                .padding(22.dp)
        ) {
            Column {

                Text(
                    "Luxury Collection",
                    fontSize = 25.sp,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    "Up to 50% OFF",
                    fontSize = 18.sp,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    "Premium perfumes for every mood",
                    fontSize = 14.sp,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            "Fragrance Type",
            fontSize = 22.sp,
            color = Color(0xFF24112E)
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow {

            items(fragranceTypes) { type ->

                AssistChip(
                    onClick = {
                        selectedType = type
                    },

                    label = {
                        Text(type)
                    },

                    modifier = Modifier.padding(end = 8.dp),

                    colors = AssistChipDefaults.assistChipColors(
                        containerColor =
                            if (selectedType == type)
                                Color(0xFF8E24AA)
                            else
                                Color.White,

                        labelColor =
                            if (selectedType == type)
                                Color.White
                            else
                                Color(0xFF8E24AA)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            "Popular Perfumes",
            fontSize = 22.sp,
            color = Color(0xFF24112E)
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow {

            items(filteredProducts) { product ->

                ProductCard(
                    product = product,

                    onAddToCart = {
                        cart.add(product)
                    },

                    onProductClick = {
                        onProductClick(product)
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            "Recommended For You",
            fontSize = 22.sp,
            color = Color(0xFF24112E)
        )

        Spacer(modifier = Modifier.height(12.dp))

        filteredProducts.take(3).forEach { product ->

            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 7.dp)
                    .clickable {
                        onProductClick(product)
                    },

                shape = RoundedCornerShape(24.dp),

                colors = CardDefaults.elevatedCardColors(
                    containerColor = Color.White
                )
            ) {

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),

                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = product.image),

                        contentDescription = product.name,

                        modifier = Modifier
                            .size(80.dp)
                            .clip(RoundedCornerShape(16.dp))
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(
                        modifier = Modifier.weight(1f)
                    ) {

                        Text(
                            product.name,
                            fontSize = 17.sp,
                            maxLines = 1
                        )

                        Text(
                            product.fragranceType,
                            fontSize = 13.sp,
                            color = Color(0xFF8E24AA)
                        )

                        Text(
                            "$${product.price}",
                            color = Color.Gray
                        )
                    }

                    Button(
                        onClick = {
                            cart.add(product)
                        },

                        shape = RoundedCornerShape(50.dp),

                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF8E24AA)
                        )
                    ) {
                        Text("Add to Bag")
                    }
                }
            }
        }
    }
}