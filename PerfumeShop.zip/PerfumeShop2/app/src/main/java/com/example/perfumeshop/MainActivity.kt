package com.example.perfumeshop

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.example.perfumeshop.model.Product
import com.example.perfumeshop.ui.CartScreen
import com.example.perfumeshop.ui.HomeScreen
import com.example.perfumeshop.ui.ProductDetailScreen
import com.example.perfumeshop.ui.WelcomeScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            var showWelcome by remember { mutableStateOf(true) }
            var showCart by remember { mutableStateOf(false) }
            var selectedProduct by remember { mutableStateOf<Product?>(null) }

            val cart = remember { mutableStateListOf<Product>() }

            when {
                showWelcome -> {
                    WelcomeScreen {
                        showWelcome = false
                    }
                }

                selectedProduct != null -> {
                    ProductDetailScreen(
                        product = selectedProduct!!,
                        cart = cart,
                        goBack = { selectedProduct = null }
                    )
                }

                showCart -> {
                    CartScreen(
                        cart = cart,
                        goBack = { showCart = false }
                    )
                }

                else -> {
                    HomeScreen(
                        cart = cart,
                        goToCart = { showCart = true },
                        onProductClick = { product ->
                            selectedProduct = product
                        }
                    )
                }
            }
        }
    }
}